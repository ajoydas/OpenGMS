/*
  producer.h
 *
 *  Created on: Apr 19, 2017
 *      Author: rafid
 */

#ifndef THREADS_PRODUCER_H_
#define THREADS_PRODUCER_H_
#include "copyright.h"
#include "synch.h"
#include "thread.h"
#include "system.h"

#define MAXSIZE 10
extern Lock * producer_consumer_lock;
extern Condition * prod;
extern Condition* cons;
extern List *productQueue;
extern int size;
extern int product;

class Producer{
public:
	Producer(int a);
	~Producer();
	void produce();
private:
	//Thread *pThread;
	int arg;

};



#endif /* THREADS_PRODUCER_H_ */
