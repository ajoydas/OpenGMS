/*
 * consumer.h
 *
 *  Created on: Apr 19, 2017
 *      Author: rafid
 */

#ifndef THREADS_CONSUMER_H_
#define THREADS_CONSUMER_H_
#include "copyright.h"
#include "synch.h"
#include "thread.h"
#include "system.h"

#define MAXSIZE 10
extern Lock * producer_consumer_lock;
extern Condition * prod;
extern Condition* cons;
extern List *productQueue;
extern int size;

class Consumer{
public:
	Consumer(int a);
	~Consumer();
	void consume();
private:
	//Thread *cThread;
	int arg;
};




#endif /* THREADS_CONSUMER_H_ */
