// threadtest.cc 
//	Simple test case for the threads assignment.
//
//	Create two threads, and have them context switch
//	back and forth between themselves by calling Thread::Yield, 
//	to illustratethe inner workings of the thread system.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "synch.h"
#include "producer.h"
#include "consumer.h"
// testnum is set in main.cc
int testnum = 1;
Lock * producer_consumer_lock;
Condition * prod;
Condition* cons;
List *productQueue;
int size;
int product;

//----------------------------------------------------------------------
// SimpleThread
// 	Loop 5 times, yielding the CPU to another ready thread 
//	each iteration.
//
//	"which" is simply a number identifying the thread, for debugging
//	purposes.
//----------------------------------------------------------------------

void
SimpleThread(int which)
{
    int num;
    
    for (num = 0; num < 5; num++) {
	printf("*** thread %d looped %d times\n", which, num);
        currentThread->Yield();
    }
}

//----------------------------------------------------------------------
// ThreadTest1
// 	Set up a ping-pong between two threads, by forking a thread 
//	to call SimpleThread, and then calling SimpleThread ourselves.
//----------------------------------------------------------------------

void
ThreadTest1()
{
    DEBUG('t', "Entering ThreadTest1");

    Thread *t = new Thread("forked thread");

    t->Fork(SimpleThread, 1);
    SimpleThread(0);
}

void prodThread(int arg){
	Producer *producer = new Producer(arg);
	producer->produce();


}

void consThread(int arg){
	Consumer *consumer = new Consumer(arg);
	consumer->consume();
}

//----------------------------------------------------------------------
// ThreadTest1
// 	Set up a ping-pong between two threads, by forking a thread
//	to call SimpleThread, and then calling SimpleThread ourselves.
//----------------------------------------------------------------------

void
ThreadTest2()
{
    DEBUG('t', "Entering ThreadTest2");
    productQueue = new List();
    size=0;
    product=1;
    producer_consumer_lock = new Lock("prod cons lock");
    prod = new Condition("prod cond");
    cons = new Condition("cons cond");

    Thread* pThread[10];
    Thread* cThread[10];
    for(int i=0;i<10;i++){
    	pThread[i] = new Thread("prod");
    	pThread[i]->Fork(prodThread, i+1);

    }

    for(int i=0;i<10;i++){
    	cThread[i] = new Thread("cons");
    	cThread[i]->Fork(consThread, i+1);
    }
    //SimpleThread(0);
}



//----------------------------------------------------------------------
// ThreadTest
// 	Invoke a test routine.
//----------------------------------------------------------------------

void
ThreadTest()
{
    switch (testnum) {
    case 1:
	ThreadTest1();
	//break;
    case 2:
    	ThreadTest2();
    	break;
	break;
    default:
	printf("No test specified.\n");
	break;
    }
}

