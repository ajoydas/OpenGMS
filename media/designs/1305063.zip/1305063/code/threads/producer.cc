/*
 * producer.cc

 *
 *  Created on: Apr 19, 2017
 *      Author: rafid
 */
#include "copyright.h"
#include "producer.h"


Producer::Producer(int a){
	arg= a;

	//pThread = new Thread("prodthread");

	//pThread->Fork(this->produce, arg);
}

Producer::~Producer(){
	//pThread->Finish();
	//delete pThread;
}

void
Producer::produce(){

	while(true){

//hahahahaha

		producer_consumer_lock->Acquire();
		if(size == MAXSIZE){
			prod->Wait(producer_consumer_lock);
		}
		int i = product;
		productQueue->Append((void*)&i);
		size++;
		product++;
		for(int j=0; j<60000000;j++);
		printf("producer %d produced %d\n",arg,i);
		
		producer_consumer_lock->Release();
		if(size == 1) cons->Broadcast(producer_consumer_lock);
		for(int j=0; j<60000000;j++);
		//product++;
		currentThread->Yield();
	}
}


