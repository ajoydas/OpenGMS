/*
 * consumer.cc

 *
 *  Created on: Apr 19, 2017
 *      Author: rafid
 */
#include "copyright.h"
#include "consumer.h"

Consumer::Consumer(int a){
	arg =a;
	//cThread = new Thread("consthread");
	//cThread->Fork(this->consume, arg);
};

Consumer::~Consumer(){
	//cThread->Finish();
	//delete cThread;
}

void
Consumer::consume(){

	while(true){
			producer_consumer_lock->Acquire();
			if(size == 0){
				cons->Wait(producer_consumer_lock);
			}
			int i = *((int*)productQueue->Remove());
			for(int j=0; j<60000000;j++);
			printf("consumer %d found %d\n",arg,i);
			size--;
			
			producer_consumer_lock->Release();
			if(size == MAXSIZE-1) prod->Broadcast(producer_consumer_lock);

			for(int j=0; j<60000000;j++);
			currentThread->Yield();
		}
}



