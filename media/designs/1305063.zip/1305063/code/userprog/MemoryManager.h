/*
 * MemoryManager.h
 *
 *  Created on: May 8, 2017
 *      Author: rafid
 */

#ifndef USERPROG_MEMORYMANAGER_H_
#define USERPROG_MEMORYMANAGER_H_

#include "copyright.h"
#include "bitmap.h"
#include "synch.h"
#include "translate.h"
/* Create a manager to track the allocation of numPages of physical memory.
   You will create one by calling the constructor with NumPhysPages as
   the parameter.  All physical pages start as free, unallocated pages. */

class SwapSpace{
public:
	int virtualPageNo;
	int processId;
	char* swapPageData;
	SwapSpace(){
		processId = -1;
		virtualPageNo = -1;
		swapPageData = new char[PageSize];
	}
};

class InvertedPageTable{
public:
	int processId;
	int physPageNo;
	int virtualPageNo;
	unsigned long long int timeStamp;
	InvertedPageTable(){
		processId = -1;
		physPageNo = -1;
		virtualPageNo = -1;
		timeStamp = 0;
	}
};

class MemoryManager{
public:
	MemoryManager(int numPages);
	~MemoryManager();
	/* Allocate a free page, returning its physical page number or -1
	   if there are no free pages available. */
	int AllocPage();
	int AllocByForce();
	//int Alloc(int processId, TranslationEntry &entry);
	/* Free the physical page and make it available for future allocation. */
	void FreePage(int physPageNum);

	/* True if the physical page is allocated, false otherwise. */
	bool PageIsAllocated(int physPageNum);

	int numOfFreePages();



private:
	BitMap* bitMap;
	Lock* memLock;
	int numPages;
};





#endif /* USERPROG_MEMORYMANAGER_H_ */
