/*

 * MemoryManager.cc
 *
 *  Created on: May 8, 2017
 *      Author: rafid
 */
#include "copyright.h"
#include "system.h"
#include "MemoryManager.h"
#include "processtable.h"

extern InvertedPageTable* invertedPageTable;
extern Table* processTable;

MemoryManager::MemoryManager(int numPages){
	this->numPages = numPages;
	bitMap = new BitMap(numPages);
	memLock = new Lock("memlock");
}

int
MemoryManager::AllocPage(){
	memLock->Acquire();
	int retVal = bitMap->Find();
	memLock->Release();
	return retVal;

}
int
MemoryManager::AllocByForce(){
	memLock->Acquire();
	int retVal = Random()%numPages;
	unsigned long long int time = invertedPageTable[0].timeStamp;
	for(int i=0;i<numPages;i++){
		if(invertedPageTable[i].timeStamp < time ){

			retVal = i;
			time = invertedPageTable[i].timeStamp;
			printf("\n\n\n__________time = %d_____\n\n\n",time);
		}
	}
	memLock->Release();
	return retVal;
}

void
MemoryManager::FreePage(int phyPageNum){
	memLock->Acquire();
	bitMap->Clear(phyPageNum);
	memLock->Release();
}

bool
MemoryManager::PageIsAllocated(int phyPageNum){
	memLock->Acquire();
	bool retVal = bitMap->Test(phyPageNum);
	memLock->Release();
	return retVal;
}

int
MemoryManager::numOfFreePages(){
	memLock->Acquire();
	int count = bitMap->NumClear();
	memLock->Release();
	return count;
}

MemoryManager::~MemoryManager(){
	delete memLock;
	delete bitMap;
}

