/*
 * synchconsole.cc

 *
 *  Created on: May 11, 2017
 *      Author: rafid
 */

#include "synchconsole.h"
typedef int OpenFileId;

extern Semaphore* semRead;
extern Semaphore* semWrite;
static void isReadAvailable(int arg){
	semRead->V();
}

static void isWriteAvailable(int arg){
	semWrite->V();
}

SynchConsole::SynchConsole(){
	consoleLock = new Lock("consoleLock");
	console = new Console(NULL,NULL,isReadAvailable,isWriteAvailable,0);
	semRead = new Semaphore("semRead", 0);
	semWrite = new Semaphore("semWrite", 0);

}

SynchConsole::~SynchConsole(){
	delete console;
	delete consoleLock;
}

int
SynchConsole::SynchRead(int buffer, int size){
	printf("\n\n___________________sync read__________________\n\n");
	consoleLock->Acquire();
	int dest;
	char ch;
	int i;
	int bytesRead=0;
		for(i=0;i<size;i++){
			semRead->P();
			ch = console->GetChar();

			//printf("%c\n",ch);
			if(ch != '\n'){
				dest = buffer+i;
//				buffer+=i;
//				*buffer=ch;
//				buffer-=i;
				machine->WriteMem(dest, 1, ch);
				//printf("buffer+i = %d\n",(int)(buffer+i));
				//printf("__________buffer[i] = %c_______\n",*(buffer+i));
				bytesRead++;
			}
			else{
				dest =(int) (buffer+i);
				machine->WriteMem(dest, 1, NULL);
				consoleLock->Release();
				return bytesRead;
			}
		}

	consoleLock->Release();
	return bytesRead;
}

void
SynchConsole::SynchWrite(int buffer, int size){
	printf("\n\n___________________sync write__________________\n\n");
	consoleLock->Acquire();
	char ch;
	for(int i=0;i<size;i++){
		int src = buffer+i;
		int chInt;

		if(!machine->ReadMem(src,1,&chInt))  printf("\nsomething\n");
		ch = (char) chInt;

		console->PutChar(ch);
		if(ch == '\n' || ch == '\0') {
			semWrite->P();
			break;
		}
		semWrite->P();
	}
	ch = '\n';
	console->PutChar(ch);
	consoleLock->Release();
}




