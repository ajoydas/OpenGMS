// addrspace.cc 
//	Routines to manage address spaces (executing user programs).
//
//	In order to run a user program, you must:
//
//	1. link with the -N -T 0 option 
//	2. run coff2noff to convert the object file to Nachos format
//		(Nachos object code format is essentially just a simpler
//		version of the UNIX executable object code format)
//	3. load the NOFF file into the Nachos file system
//		(if you haven't implemented the file system yet, you
//		don't need to do this last step)
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "addrspace.h"
#include "machine.h"
#include "MemoryManager.h"
#ifdef HOST_SPARC
#include <strings.h>
#endif

//----------------------------------------------------------------------
// SwapHeader
// 	Do little endian to big endian conversion on the bytes in the 
//	object file header, in case the file was generated on a little
//	endian machine, and we're now running on a big endian machine.
//----------------------------------------------------------------------
extern Machine * machine;
extern MemoryManager* memoryManager;
extern MemoryManager* swapMemoryManager;
extern SwapSpace* swapSpace;
extern Lock* pageTableLock;
extern Lock* memWriteLock;

static void 
SwapHeader (NoffHeader *noffH)
{
	noffH->noffMagic = WordToHost(noffH->noffMagic);
	noffH->code.size = WordToHost(noffH->code.size);
	noffH->code.virtualAddr = WordToHost(noffH->code.virtualAddr);
	noffH->code.inFileAddr = WordToHost(noffH->code.inFileAddr);
	noffH->initData.size = WordToHost(noffH->initData.size);
	noffH->initData.virtualAddr = WordToHost(noffH->initData.virtualAddr);
	noffH->initData.inFileAddr = WordToHost(noffH->initData.inFileAddr);
	noffH->uninitData.size = WordToHost(noffH->uninitData.size);
	noffH->uninitData.virtualAddr = WordToHost(noffH->uninitData.virtualAddr);
	noffH->uninitData.inFileAddr = WordToHost(noffH->uninitData.inFileAddr);
}

//----------------------------------------------------------------------
// AddrSpace::AddrSpace
// 	Create an address space to run a user program.
//	Load the program from a file "executable", and set everything
//	up so that we can start executing user instructions.
//
//	Assumes that the object code file is in NOFF format.
//
//	First, set up the translation from program memory to physical 
//	memory.  For now, this is really simple (1:1), since we are
//	only uniprogramming, and we have a single unsegmented page table
//
//	"executable" is the file containing the object code to load into memory
//----------------------------------------------------------------------

AddrSpace::AddrSpace(OpenFile *exec)
{
    //NoffHeader noffH;
	this->executable = exec;
    unsigned int i, size;
    printf("......................ADDRSPACE.........................1\n");
    executable->ReadAt((char *)&noffH, sizeof(noffH), 0);
    printf("......................ADDRSPACE.........................2\n");
    if ((noffH.noffMagic != NOFFMAGIC) && 
		(WordToHost(noffH.noffMagic) == NOFFMAGIC))
    	SwapHeader(&noffH);

    ASSERT(noffH.noffMagic == NOFFMAGIC);

// how big is address space?
    size = noffH.code.size + noffH.initData.size + noffH.uninitData.size 
			+ UserStackSize;	// we need to increase the size
						// to leave room for the stack
    numPages = divRoundUp(size, PageSize);
    size = numPages * PageSize;

    //ASSERT(numPages <= memoryManager->numOfFreePages());		// check we're not trying
						// to run anything too big --
						// at least until we have
						// virtual memory

    DEBUG('a', "Initializing address space, num pages %d, size %d\n", 
					numPages, size);
// first, set up the translation 
    //pageTableLock->Acquire();
    pageTable = new TranslationEntry[numPages];
    for (i = 0; i < numPages; i++) {
		pageTable[i].virtualPage = i;	// for now, virtual page # = phys page #
		pageTable[i].physicalPage =-1, // memoryManager->AllocPage();
		//ASSERT(pageTable[i].physicalPage != -1); //returns if no space available
	    pageTable[i].swapPage = -1;
		pageTable[i].timeStamp = 0;
		pageTable[i].valid = FALSE;
		pageTable[i].use = FALSE;
		pageTable[i].dirty = FALSE;
		pageTable[i].readOnly = FALSE;  // if the code segment was entirely on
						// a separate page, we could set its
						// pages to be read-only
    }
    //pageTableLock->Release();

// zero out the entire address space, to zero the unitialized data segment 
// and the stack segment
//   bzero(machine->mainMemory, size);
   // memWriteLock->Acquire();
//    IntStatus oldLevel = interrupt->SetLevel(IntOff);
//	for(unsigned int x=0; x < numPages; x++){
//			bzero(&machine -> mainMemory[PageSize * pageTable[x].physicalPage], PageSize);
//		}
//
//    TranslationEntry * temp = machine->pageTable;
//	int tempSize =  machine->pageTableSize;
//	machine->pageTable = pageTable;
//	machine->pageTableSize = numPages;
//
//	int codeVirtualOffset = noffH.code.virtualAddr;
//	int codeSize = divRoundUp(noffH.code.size , PageSize);
//	int codeFileOffset = noffH.code.inFileAddr;
//
//	int dataVirtualOffset = noffH.initData.virtualAddr;
//	int dataSize = noffH.initData.size;
//	int dataFileOffset = noffH.initData.inFileAddr;
//
//	for(int i=0; i<codeSize;i++){
//		char* fourBytes;
//		executable->ReadAt(fourBytes, 4, noffH.code.inFileAddr);
//		machine->WriteMem(codeVirtualOffset, 4, fourBytes);
//		codeVirtualOffset+=4;
//		codeFileOffset+=4;
//	}
//
//	for(int i=0; i<dataSize;i++){
//			char* fourBytes;
//			executable->ReadAt(fourBytes, 4, noffH.initData.inFileAddr);
//			machine->WriteMem(dataVirtualOffset, 4, fourBytes);
//			dataVirtualOffset+=4;
//			dataFileOffset+=4;
//		}
//
//
//	 machine->pageTable= temp;
//	 machine->pageTableSize = tempSize;
//
//	 interrupt->SetLevel(oldLevel);
// then, copy in the code and data segments into memory
//    IntStatus iStat = interrupt->SetLevel(IntOff);
//    for(unsigned int x=0; x < numPages; x++){
//        	bzero(&machine -> mainMemory[PageSize * pageTable[x].physicalPage], PageSize);
//        }
//    unsigned int pagesReqCode=divRoundUp(noffH.code.size , PageSize);
//    unsigned int pagesReqData=divRoundUp(noffH.initData.size, PageSize);
//
//    if (noffH.code.size > 0){
//    		unsigned int codeVirtual = noffH.code.virtualAddr;
//    		for (unsigned int x=0; x < pagesReqCode; x++){
//    						unsigned int physAddr = translateToPhysicalAddr(codeVirtual);
//    						char* physBuff = &(machine -> mainMemory[physAddr]);
//    						int size = PageSize;
//    						int fileOff = noffH.code.inFileAddr + x * PageSize;
//    						executable -> ReadAt( physBuff, size, fileOff) ;
//    						codeVirtual+=PageSize;
//    		}
//
//        }
//
//    if (noffH.initData.size > 0){
//    	unsigned int dataVirtual = noffH.initData.virtualAddr;
//       		for (unsigned int x=0; x < pagesReqData; x++){
//       						unsigned int physAddr = translateToPhysicalAddr(dataVirtual);
//       						char* physBuff = &(machine -> mainMemory[physAddr]);
//       						int size = PageSize;
//       						int fileOff = noffH.initData.inFileAddr + x * PageSize;
//       						executable -> ReadAt( physBuff, size, fileOff) ;
//       						dataVirtual+=PageSize;
//       		}
//
//       }
//
//    	interrupt->SetLevel(iStat);
//   // memWriteLock->Release();


//    if (noffH.code.size > 0) {
//        DEBUG('a', "Initializing code segment, at 0x%x, size %d\n",
//			noffH.code.virtualAddr, noffH.code.size);
//        executable->ReadAt(&(machine->mainMemory[noffH.code.virtualAddr]),
//			noffH.code.size, noffH.code.inFileAddr);
//    }
//    if (noffH.initData.size > 0) {
//        DEBUG('a', "Initializing data segment, at 0x%x, size %d\n",
//			noffH.initData.virtualAddr, noffH.initData.size);
//        executable->ReadAt(&(machine->mainMemory[noffH.initData.virtualAddr]),
//			noffH.initData.size, noffH.initData.inFileAddr);
//    }

}


unsigned int
AddrSpace::translateToPhysicalAddr(int virtualAddr){
	unsigned int physicalAddr,offset, pageFrame,virtualPageNum;
	virtualPageNum = (unsigned)virtualAddr/PageSize;
	offset = virtualAddr%PageSize;
	pageFrame = pageTable[virtualPageNum].physicalPage;
	physicalAddr = pageFrame*PageSize+offset;
	return physicalAddr;

}

int
AddrSpace::loadIntoFreePage(int addr, int physicalPageNo){
	int vpn = addr/PageSize;
	pageTable[vpn].physicalPage = physicalPageNo;
	pageTable[vpn].valid = TRUE;
	printf("\n\n\n");
	printf("code size = %d data size %d undata size = %d\n\n",noffH.code.size, noffH.initData.size, noffH.uninitData.size);

	if(isSwapPageExists(vpn)){
		printf("swap page no = %d\n", pageTable[vpn].swapPage);
		loadFromSwapSpace(vpn);
		printf("\n\n______________Loading from swap memory_________\n\n");
		return 0;
	}

	int codeOffset=0, codeSize=0, initDataOffset=0, initDataSize=0, uninitDataOffset=0, uninitDataSize=0;
	int physAddr = physicalPageNo*PageSize;
	if(noffH.code.virtualAddr <= addr && (noffH.code.virtualAddr + noffH.code.size) > addr){
		codeOffset = (addr - noffH.code.virtualAddr)/PageSize;
		codeSize = noffH.code.size - codeOffset*PageSize;
		codeSize = min(codeSize, PageSize);
		if(noffH.code.size > 0){
			printf("___code = %d___\n", codeSize);
			executable->ReadAt(&machine->mainMemory[physAddr], codeSize, noffH.code.inFileAddr + codeOffset*PageSize);
		}
		if(codeSize < PageSize){
			initDataSize = PageSize - codeSize;
			initDataSize = min(initDataSize, noffH.initData.size);
			printf("___code mid init data = %d___\n", initDataSize);
			if(noffH.initData.size > 0){
				executable->ReadAt(&machine->mainMemory[physAddr + codeSize], initDataSize, noffH.initData.inFileAddr);
			}
		}
		if((codeSize + initDataSize) < PageSize){
			int freePageSize = PageSize - codeSize - initDataSize;
			printf("___code mid uninit data = %d___\n", freePageSize);
			bzero(&machine->mainMemory[physAddr + codeSize + initDataSize], freePageSize);
		}
	}
	else if(noffH.initData.virtualAddr <= addr && (noffH.initData.virtualAddr + noffH.initData.size) > addr){
		initDataOffset = (addr - noffH.initData.virtualAddr)/PageSize;
		initDataSize = min(noffH.initData.size - initDataOffset*PageSize, PageSize);
		if(noffH.initData.size > 0 ){
			printf("___init data = %d___\n", initDataSize);
			executable->ReadAt(&machine->mainMemory[physAddr], initDataSize, noffH.initData.inFileAddr + initDataOffset*PageSize);
		}
		if(initDataSize < PageSize){
			int freePageSize = PageSize - initDataSize;
			printf("___init mid uninit data = %d___\n", freePageSize);
			bzero(&machine->mainMemory[physAddr + initDataSize], freePageSize);
		}
	}
	else if(noffH.uninitData.virtualAddr <= addr && (noffH.uninitData.virtualAddr + noffH.uninitData.size) > addr){
		printf("___uninit  data = %d___\n", PageSize);
		bzero(&machine->mainMemory[physAddr], PageSize);
	}
	else{
		printf("___zero = %d___\n", PageSize);
		bzero(&machine->mainMemory[physAddr], PageSize);
	}
	printf("\n\n\n");
	return 0;
}

TranslationEntry*
AddrSpace::getPageTable(){
	return pageTable;
}
int
AddrSpace::getNumPages(){
	return numPages;
}

void
AddrSpace::loadFromSwapSpace(int vpn){
	int physAddr = pageTable[vpn].physicalPage*PageSize;
	int swapPageNo = pageTable[vpn].swapPage;
	IntStatus oldLevel = interrupt->SetLevel(IntOff);
	bcopy(swapSpace[swapPageNo].swapPageData, &machine->mainMemory[physAddr], PageSize);
	stats->pageIns++;
	interrupt->SetLevel(oldLevel);
//	for(int i=0;i<PageSize;i++){
//				char ch =machine->mainMemory[physAddr+i];
//				printf("%c",ch);
//			}
//			printf("\n");
//		for(int i=0;i<PageSize;i++){
//			char ch = swapSpace[swapPageNo].swapPageData[i];
//			printf("%c",ch);
//		}
//		printf("\n");
}

void
AddrSpace::saveIntoSwapSpace(int vpn, int processId){
	int freeSwapPage;
	if(isSwapPageExists(vpn)){
		freeSwapPage = pageTable[vpn].swapPage;
	}
	else {
		freeSwapPage = swapMemoryManager->AllocPage();
		pageTable[vpn].swapPage = freeSwapPage;
	}

	swapSpace[freeSwapPage].virtualPageNo = vpn;
	swapSpace[freeSwapPage].processId = processId;
	int physAddr = pageTable[vpn].physicalPage*PageSize;
	IntStatus oldLevel = interrupt->SetLevel(IntOff);
	bcopy(&machine->mainMemory[physAddr], swapSpace[freeSwapPage].swapPageData, PageSize);
	stats->pageOuts++;
	interrupt->SetLevel(oldLevel);
	printf("\n____saving into swap space____\n");


}

bool
AddrSpace::isSwapPageExists(int vpn){
	return pageTable[vpn].swapPage != -1;
}

int
AddrSpace::getTimeStamp(int vpn){
	return pageTable[vpn].timeStamp;
}

void
AddrSpace::setTimeStamp(int vpn, unsigned long long int time){
	pageTable[vpn].timeStamp = time;
}

//----------------------------------------------------------------------
// AddrSpace::~AddrSpace
// 	Dealloate an address space.  Nothing for now!
//----------------------------------------------------------------------

AddrSpace::~AddrSpace()
{
//	for(int i=0;i<numPages;i++){
//		memoryManager->FreePage(pageTable[i].physicalPage);
//	}
	delete executable;
   delete pageTable;
}

//----------------------------------------------------------------------
// AddrSpace::InitRegisters
// 	Set the initial values for the user-level register set.
//
// 	We write these directly into the "machine" registers, so
//	that we can immediately jump to user code.  Note that these
//	will be saved/restored into the currentThread->userRegisters
//	when this thread is context switched out.
//----------------------------------------------------------------------

void
AddrSpace::InitRegisters()
{
    int i;

    for (i = 0; i < NumTotalRegs; i++)
	machine->WriteRegister(i, 0);

    // Initial program counter -- must be location of "Start"
    machine->WriteRegister(PCReg, 0);	

    // Need to also tell MIPS where next instruction is, because
    // of branch delay possibility
    machine->WriteRegister(NextPCReg, 4);

   // Set the stack register to the end of the address space, where we
   // allocated the stack; but subtract off a bit, to make sure we don't
   // accidentally reference off the end!
    machine->WriteRegister(StackReg, numPages * PageSize - 16);
    DEBUG('a', "Initializing stack register to %d\n", numPages * PageSize - 16);
}

//----------------------------------------------------------------------
// AddrSpace::SaveState
// 	On a context switch, save any machine state, specific
//	to this address space, that needs saving.
//
//	For now, nothing!
//----------------------------------------------------------------------

void AddrSpace::SaveState() 
{}

//----------------------------------------------------------------------
// AddrSpace::RestoreState
// 	On a context switch, restore the machine state so that
//	this address space can run.
//
//      For now, tell the machine where to find the page table.
//----------------------------------------------------------------------

void AddrSpace::RestoreState() 
{
    machine->pageTable = pageTable;
    machine->pageTableSize = numPages;
}
