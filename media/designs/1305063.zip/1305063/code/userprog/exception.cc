// exception.cc 
//	Entry point into the Nachos kernel from user programs.
//	There are two kinds of things that can cause control to
//	transfer back to here from user code:
//
//	syscall -- The user code explicitly requests to call a procedure
//	in the Nachos kernel.  Right now, the only function we support is
//	"Halt".
//
//	exceptions -- The user code does something that the CPU can't handle.
//	For instance, accessing memory that doesn't exist, arithmetic errors,
//	etc.  
//
//	Interrupts (which can also cause control to transfer from user
//	code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"

#include "openfile.h"
#include "syscall.h"
#include "addrspace.h"
#include "synch.h"
#include "processtable.h"
#include "MemoryManager.h"
#include "console.h"
#include "synchconsole.h"
//#ifndef MACHINE_H
#include "machine.h"
//#include "stats.h"
//#endif
#define E_MAX_SIZE 200
extern Machine * machine;
extern int time;
extern Lock* execLock;
extern Table* processTable;
extern MemoryManager* memoryManager;
extern InvertedPageTable* invertedPageTable;

//extern  Console *console;

extern SynchConsole* synchConsole;
extern Semaphore* semRead;
extern Semaphore* semWrite;

void runFunction(int id){
	currentThread->space->InitRegisters();
	currentThread->space->RestoreState();
	//printf("\n\nrunFunction executing with id = %d\n\n",id);
	machine->Run();
	//printf("\n\nrunFunction executing with id = %d\n\n",id);
	ASSERT(FALSE);
}


void Write(int buffer, int size, OpenFileId id){

	synchConsole->SynchWrite(buffer, size);

}

int Read(int buffer, int size, OpenFileId id){

	int retSize = synchConsole->SynchRead(buffer, size);
	//printf("__________buffer  = %s_______\n",buffer);
	return retSize;
}


/* Read "size" bytes from the open file into "buffer".
 * Return the number of bytes actually read -- if the open file isn't
 * long enough, or if it is an I/O device, and there aren't enough
 * characters to read, return whatever is available (for I/O devices,
 * you should always wait until you can return at least one character).
 */

void incrementPC(){
	int pc = machine->ReadRegister(PCReg);
	machine->WriteRegister(PrevPCReg, pc);
	pc = machine->ReadRegister(NextPCReg);
	machine->WriteRegister(PCReg, pc);
	pc+=4;
	machine->WriteRegister(NextPCReg, pc);
}


void myExit(int status){
	execLock->Acquire();
	printf("__..................Exit is executing with status  %d........................__.\n", status);
	int pageTblSize = machine->pageTableSize;
	for(int i=0;i<pageTblSize;i++){
		if(machine->pageTable[i].valid) {
			memoryManager->FreePage(machine->pageTable[i].physicalPage);
			if(invertedPageTable[machine->pageTable[i].physicalPage].processId == currentThread->spaceId){
				invertedPageTable[machine->pageTable[i].physicalPage].processId=-1;
				invertedPageTable[machine->pageTable[i].physicalPage].virtualPageNo = -1;
				//invertedPageTable[machine->pageTable[i].physicalPage].physPageNo = -1;
				invertedPageTable[machine->pageTable[i].physicalPage].timeStamp = 0;
			}

		}

	}
	printf("________________exiting  %s_________________\n",currentThread->getName());
	printf("________________exiting process id %d_________________\n",currentThread->spaceId);
	processTable->Release(currentThread->spaceId);
	if(processTable->getNumProcess() == 0){
		printf("________I am actually in exit's halt______\n");
		execLock->Release();
		interrupt->Halt();
	}

	/*if(status !=-1) printf("Program exited with %d\n", status);
	else printf("Program exited with error %d\n", status);*/
	execLock->Release();
	currentThread->Finish();

}


SpaceId Exec(char *name) {


	OpenFile* executable = fileSystem->Open(name);
	//ASSERT(executable != NULL);
	if(executable == NULL){
		printf("Unable to open file %s\n", name);
			return -1;
	}
	printf("..............Exec is executing for...........%s\n",name);
	AddrSpace* spc = new AddrSpace(executable);
	Thread* thread = new Thread("test");
	//printf("..............Exec is executing...........2\n");
	thread->spaceId = processTable->Alloc((void*)thread);
	//printf("\n\n___________get num curr process = %d___________\n\n",processTable->getNumProcess());
	//printf("..............Exec is executing...........3\n");
	//printf("..............Exec is executing...........4\n");
	thread->space = spc;
	//printf("..............Exec is executing...........5\n");
	//delete executable;
	return thread->spaceId;
}



//----------------------------------------------------------------------
// ExceptionHandler
// 	Entry point into the Nachos kernel.  Called when a user program
//	is executing, and either does a syscall, or generates an addressing
//	or arithmetic exception.
//
// 	For system calls, the following is the calling convention:
//
// 	system call code -- r2
//		arg1 -- r4
//		arg2 -- r5
//		arg3 -- r6
//		arg4 -- r7
//
//	The result of the system call, if any, must be put back into r2. 
//
// And don't forget to increment the pc before returning. (Or else you'll
// loop making the same system call forever!
//
//	"which" is the kind of exception.  The list of possible exceptions 
//	are in machine.h.
//----------------------------------------------------------------------

void
ExceptionHandler(ExceptionType which)
{
    int type = machine->ReadRegister(2);
    int arg1 = machine->ReadRegister(4);
    int arg2 = machine->ReadRegister(5);
    int arg3 = machine->ReadRegister(6);
    int arg4 = machine->ReadRegister(7);
//    printf("______syscall = %d_________\n",which);
//    printf("______type = %d_________\n",type);
    if (which == SyscallException) {
    	if(type == SC_Halt){

			DEBUG('a', "Shutdown, initiated by user program.\n");
			interrupt->Halt();
    	}

    	else if(type == SC_Exit){
    		myExit(arg1);
    	}

    	else if(type == SC_Exec){
        	execLock->Acquire();
				int pathAddress = arg1;

				char buffer[E_MAX_SIZE];
				int i=0;
				int var;
				if(!machine->ReadMem(pathAddress, 1, &var)){
					execLock->Acquire();
					if(!machine->ReadMem(pathAddress, 1, &var)){
					  myExit(-1);
					}
				}
				while((*(char*)&var) != '\0'){
					buffer[i] = (char) var;
					printf("\n--------------- %c --------------\n",buffer[i]);
					i++;
					pathAddress++;
					if(!machine->ReadMem(pathAddress, 1, &var)){
						execLock->Acquire();
						if(!machine->ReadMem(pathAddress, 1, &var)){
						  myExit(-1);
						}
					}
				}
				buffer[i]='\0';
				//printf("\n--------------- %s --------------\n",buffer);
				SpaceId retVal = Exec(buffer);
				//printf("..............Exec is executing...........6\n");
//				if(retVal == -1){
//					printf("__________not enough memory__________\n");
//					return;
//				}
				//printf("..............Exec is executing...........7\n");
				machine->WriteRegister(2, retVal);

				execLock->Release();
				Thread* thr = (Thread*) processTable->Get(retVal);
				//printf("..............Exec is executing...........8\n");
				thr->Fork(runFunction, retVal);
				//printf("..............Exec is executing...........9........retVal = %d\n",retVal);
				incrementPC();

        }


    	else if(type == SC_Read){
    		//char* buff = (char*)arg1;
    		printf("read = %d\n",arg1);
    		execLock->Acquire();
    		int size = Read( arg1, arg2, arg3);
    		//printf("size = %d ______buff = %s\n",size,(char*)arg1);
    		machine->WriteRegister(2,size);
    		execLock->Release();
    		incrementPC();
    	}
    	else if(type == SC_Write){
    		//char* buff = (char*)arg1;
    		printf("write = %d\n",arg1);
    		execLock->Acquire();
			Write(arg1, arg2,0);
			//printf("size = %d\n",size);
			machine->WriteRegister(2,0);
			execLock->Release();
			incrementPC();
    	}





    } else {
		//printf("Unexpected user mode exception %d %d\n", which, type);
		if(which==AddressErrorException)
		{
			if(!execLock->isBusy()){
				execLock->Release();
			}
			printf("Address error exception\n");
			myExit(-1);
		}
		else if(which==PageFaultException)
		{
			if(!execLock->isBusy()){
				execLock->Release();
			}
			execLock->Acquire();
			stats->numPageFaults++;
			printf("Page fault exception for process = %d\n", currentThread->spaceId);
			int faultAddr = machine->ReadRegister(39);
			int vpn = faultAddr/PageSize;
			int physPageNo;
			if(memoryManager->numOfFreePages() > 0){
				physPageNo = memoryManager->AllocPage();

			}
			else{
				//replace Page
				printf("\n\n___Alloc by force___\n\n");
				physPageNo = memoryManager->AllocByForce();
				int processNo = invertedPageTable[physPageNo].processId;
				int virtNo = invertedPageTable[physPageNo].virtualPageNo;
				Thread* process = (Thread*)processTable->Get(processNo);
				TranslationEntry* table = process->space->getPageTable();
				if( table->swapPage == -1 || table[virtNo].dirty ){

					process->space->saveIntoSwapSpace(virtNo, processNo);

				}
				table[virtNo].valid = FALSE;
				table[virtNo].physicalPage = -1;

			}
			//printf("vpn = %d faultAddr = %d physPageNo = %d\n",vpn, faultAddr, physPageNo);
			//time++;
			printf("\n\n\n____global time_____%d\n\n\n",time);
			//currentThread->space->setTimeStamp(vpn, time);
			invertedPageTable[physPageNo].processId = currentThread->spaceId;
			invertedPageTable[physPageNo].physPageNo = physPageNo;
			invertedPageTable[physPageNo].virtualPageNo =vpn;
			invertedPageTable[physPageNo].timeStamp = currentThread->space->getTimeStamp(vpn);
			currentThread->space->loadIntoFreePage(vpn*PageSize, physPageNo);


			execLock->Release();
		}
		else if(which==BusErrorException)
		{
			if(!execLock->isBusy()){
				execLock->Release();
			}
			printf("Bus error exception\n");
			myExit(-1);
		}
		else if(which==ReadOnlyException)
		{
			if(!execLock->isBusy()){
				execLock->Release();
			}
			printf("Read only exception\n");
			myExit(-1);
		}
		else if(which==OverflowException)
		{
			if(!execLock->isBusy()){
				execLock->Release();
			}
			printf("overflow exception\n");
			myExit(-1);
		}
		else if(which==IllegalInstrException)
		{
			if(!execLock->isBusy()){
				execLock->Release();
			}
			printf("illegal instruction exception\n");
			myExit(-1);
		}
		else if(which==NumExceptionTypes)
		{
			if(!execLock->isBusy()){
				execLock->Release();
			}
			printf("num type exception\n");
			myExit(-1);
		}

    }

}
