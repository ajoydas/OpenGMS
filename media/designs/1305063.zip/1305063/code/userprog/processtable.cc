/*
 * processtable.cc
 *
 *  Created on: May 9, 2017
 *      Author: rafid
 */
#include "copyright.h"
#include "processtable.h"

Table::Table(int size){
	this->size = size;
	numCurrProcess = 0;
	procTableLock = new Lock("pocessLock");
	processMap = new BitMap(size);
	processTable = new Pair[size];


}

Table::~Table(){
	delete procTableLock;
	delete processMap;
	delete [] processTable;
}

int
Table::Alloc(void *object){
	procTableLock->Acquire();
	int idx = processMap->Find();
	Pair pair;
	if(idx != -1){
			pair.index = idx;
			pair.object = object;
			processTable[idx] = pair;
			numCurrProcess++;
	}
	printf("______number of processe = %d________\n",numCurrProcess);
	procTableLock->Release();
	return idx;
}

void *
Table::Get(int index){
	procTableLock->Acquire();
	void* object = (index >= 0 && index < size && processMap->Test(index))?processTable[index].object : 0;
	procTableLock->Release();
	return object;
}

int
Table::getNumProcess(){
	return numCurrProcess;
}

void
Table::Release(int index) {
	procTableLock->Acquire();
	if(processMap->Test(index)){
		numCurrProcess--;
		processMap->Clear(index);
	}
	procTableLock->Release();
}

