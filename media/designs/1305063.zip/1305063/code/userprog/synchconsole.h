/*
 * synchconsole.h
 *
 *  Created on: May 11, 2017
 *      Author: rafid
 */

#ifndef USERPROG_SYNCHCONSOLE_H_
#define USERPROG_SYNCHCONSOLE_H_
#include "console.h"
#include "system.h"
#ifndef SYNCH_H
#include "synch.h"
#endif

class SynchConsole{
public:
	SynchConsole();
	~SynchConsole();
	int SynchRead(int  buffer, int size);
	void SynchWrite(int buffer, int size);
	Console *console;
	Lock* consoleLock;

};




#endif /* USERPROG_SYNCHCONSOLE_H_ */
