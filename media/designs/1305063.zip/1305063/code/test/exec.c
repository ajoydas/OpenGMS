/*
 * exec.c
 *
 * Exec a simple program.  Return the result of Exec.
 */

#include "syscall.h"

int
main()
{
    int result = 1000;
    
    char*buff;
    int s= Read(buff, 10,0);
    Write(buff, 10, 0);
    result = Exec("../test/sort");
    Exit(result);
}
