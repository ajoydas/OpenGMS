#include "syscall.h"

int
main()
{
    Exec("../test/exittest");
    Exit(1);
}
