#ifndef MEMORYMANAGER_H
#define MEMORYMANAGER_H

#ifndef BITMAP_H
#include "bitmap.h"
#endif

#include "processtable.h"
#ifndef SYNCH_H
#include "synch.h"
#endif
extern ProcessTable *processTable;
class MemoryManager{
public:
	MemoryManager(int numPages);
	~MemoryManager();
	int AllocPage();
	void FreePage(int physPageNum);
	bool PageIsAllocated(int physPageNum);
	bool IsAnyPageFree();
	int NumFreePages();
	int Alloc(int processNo, TranslationEntry *entry);
    int AllocByForce(int processNo, TranslationEntry *entry);
    int randomAllocByForce(int processNo, TranslationEntry *entry);
    int frametoreplace();
private:
	BitMap *bitMap;
	Lock *lock;
	int *processMap;
    TranslationEntry **entries;
    int numPages ;
    unsigned randtemp;
};

#endif
