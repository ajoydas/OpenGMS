#include "memorymanager.h"

MemoryManager::MemoryManager(int numPages)
{
	bitMap = new BitMap(numPages);
	lock = new Lock("lock of memory manager");
	processMap = new int[numPages];
	for(int i=0;i<numPages;i++)processMap[i]=-1;
	entries =new TranslationEntry*[numPages];
	this->numPages = numPages ;
        randtemp=1;
}

MemoryManager::~MemoryManager()
{
	delete bitMap;
	delete lock;
	
}

int
MemoryManager::AllocPage()
{
	lock->Acquire();
	int ret = bitMap->Find();
	lock->Release();
	return ret;
}

void
MemoryManager::FreePage(int physPageNum)
{
	lock->Acquire();
	bitMap->Clear(physPageNum);
	lock->Release();
}
int
MemoryManager::Alloc(int processNo, TranslationEntry  *entry){

	int ret=AllocPage();
	processMap[ret]=processNo;
	entries[ret]=entry ;
	
	return ret ;
}

int
MemoryManager::AllocByForce(int processNo, TranslationEntry *entry){
	int ret ;

	int min=0;
	for(int i=0;i<numPages ;i++)
	{
		
		if(entries[i]->time<entries[min]->time)
			 min=i ;
	}
	
	ret=min ;
	
	lock->Acquire();
	printf("evicting physical page no: %d at time: %d\n",entries[ret]->physicalPage ,entries[ret]->time);
	Thread * t =((Thread *)(processTable->Get(processMap[ret]))) ;
	if(t->space->isSwapPageExists(entries[ret]->virtualPage)==false || entries[ret]->dirty )
		t->space->saveIntoSwapSpace(entries[ret]->virtualPage,t->space->isSwapPageExists(entries[ret]->virtualPage));
	
	entries[ret]->physicalPage = -1 ;
	entries[ret]->valid =false ;
	
	
	processMap[ret]=processNo ;
	entries[ret]=entry ;
	
	
	
	lock->Release();
	
	
	
	return ret ;
}
int
MemoryManager::randomAllocByForce(int processNo, TranslationEntry *entry){
	int ret ;

	
	
	ret=frametoreplace() ;
	
	lock->Acquire();
	printf("evicting physical page no: %d at time: %d\n",entries[ret]->physicalPage ,entries[ret]->time);
	Thread * t =((Thread *)(processTable->Get(processMap[ret]))) ;
	if(t->space->isSwapPageExists(entries[ret]->virtualPage)==false || entries[ret]->dirty )
		t->space->saveIntoSwapSpace(entries[ret]->virtualPage,t->space->isSwapPageExists(entries[ret]->virtualPage));
	
	entries[ret]->physicalPage = -1 ;
	entries[ret]->valid =false ;
	
	
	processMap[ret]=processNo ;
	entries[ret]=entry ;
	
	
	
	lock->Release();
	
	
	
	return ret ;
}
int MemoryManager:: frametoreplace()
	{
		 unsigned seed=randtemp;
		 int r,a,b;
	//	 printf("Input a random number seed: ");
	//	 scanf("%u",&seed);
		 srand(seed);
         printf("seed was %d\n",randtemp);
		 r=rand()%NumPhysPages;
		 randtemp++;
		 return r;

	}
bool
MemoryManager::PageIsAllocated(int physPageNum)
{
	lock->Acquire();
	bool ret = bitMap->Test(physPageNum);
	lock->Release();
	return ret;
}

bool
MemoryManager::IsAnyPageFree()
{
	lock->Acquire();
	bool ret;
	if(bitMap->NumClear() == 0)
		ret = false;
	else
		ret = true;
	lock->Release();
	return ret;
}

int
MemoryManager::NumFreePages()
{
	lock->Acquire();
	int ret = bitMap->NumClear();
	lock->Release();
	return ret;
}
