-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 12, 2018 at 08:14 AM
-- Server version: 10.0.31-MariaDB-cll-lve
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `buetian1_fairinfo`
--

-- --------------------------------------------------------

--
-- Table structure for table `adex_engenius_17_employees`
--

CREATE TABLE `adex_engenius_17_employees` (
  `id` int(11) NOT NULL,
  `stall` varchar(20) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `contact_no` varchar(255) DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `salary` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adex_engenius_17_products`
--

CREATE TABLE `adex_engenius_17_products` (
  `id` int(11) NOT NULL,
  `stall` varchar(50) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `price` varchar(25) NOT NULL,
  `availability` varchar(15) DEFAULT NULL,
  `image` longblob
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adex_engenius_17_sells`
--

CREATE TABLE `adex_engenius_17_sells` (
  `id` int(11) NOT NULL,
  `stall` varchar(20) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `employee_name` varchar(100) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `time` varchar(50) DEFAULT NULL,
  `price` varchar(50) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adex_engenius_17_stalls`
--

CREATE TABLE `adex_engenius_17_stalls` (
  `id` int(11) NOT NULL,
  `stall` varchar(50) DEFAULT NULL,
  `stall_name` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adex_engenius_17_stalls`
--

INSERT INTO `adex_engenius_17_stalls` (`id`, `stall`, `stall_name`, `owner`, `description`, `location`) VALUES
(1, 'contest1', 'contest1', 'contest1', 'contest1', 'contest1'),
(2, 'contest2', 'contest2', 'contest2', 'contest2', 'contest2'),
(3, 'contest3', 'contest3', 'contest3', 'contest3', 'contest3'),
(4, 'contest4', 'contest4', 'contest4', 'contest4', 'contest4'),
(5, 'contest5', 'contest5', 'contest5', 'contest5', 'contest5');

-- --------------------------------------------------------

--
-- Table structure for table `adex_engenius_17_users`
--

CREATE TABLE `adex_engenius_17_users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `mobile_no` bigint(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adex_engenius_17_users`
--

INSERT INTO `adex_engenius_17_users` (`id`, `username`, `password`, `mobile_no`) VALUES
(1, 'contest1', 'arfgkxoy', NULL),
(2, 'contest2', 'ddtwghrq', NULL),
(3, 'contest3', 'lnnngvar', NULL),
(4, 'contest4', 'aymzsrzt', NULL),
(5, 'contest5', 'cagbtjmp', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `book_fair_16_employees`
--

CREATE TABLE `book_fair_16_employees` (
  `id` int(11) NOT NULL,
  `stall` varchar(20) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `contact_no` varchar(255) DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL,
  `salary` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_fair_16_employees`
--

INSERT INTO `book_fair_16_employees` (`id`, `stall`, `name`, `description`, `contact_no`, `position`, `salary`) VALUES
(1, 'stall1', 'Ajoy', 'Student ', '01825075614', 'Assistant ', '5000');

-- --------------------------------------------------------

--
-- Table structure for table `book_fair_16_products`
--

CREATE TABLE `book_fair_16_products` (
  `id` int(11) NOT NULL,
  `stall` varchar(50) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `price` varchar(25) NOT NULL,
  `availability` varchar(15) DEFAULT NULL,
  `image` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_fair_16_products`
--

INSERT INTO `book_fair_16_products` (`id`, `stall`, `name`, `company`, `description`, `price`, `availability`, `image`) VALUES
(3, 'stall1', 'Microelectronic Circuits ', 'S. Sedra, C Smith', 'Famous ', '600', 'Medium', 'http://buetian14.com/fairmanagementapp/images/stall1_1477938259669'),
(7, 'stall2', 'Devdas', 'Sarat Chandra ', 'Famous', '140', 'Medium', 'http://buetian14.com/fairmanagementapp/images/stall2_1477938852487'),
(10, 'stall1', 'Harry potter', 'J k Rowling', '1st part', '800', 'Low', 'http://buetian14.com/fairmanagementapp/images/stall1_1477633981738'),
(34, 'stall1', 'Chokher Bali', 'Rabindranath Tagore', 'Renowned \nNovel by Rabindranath Tagore', '220', 'High', 'http://buetian14.com/fairmanagementapp/images/stall1_1477938587014'),
(13, 'stall2', 'Tintin in moon', 'Harz', '', '100', 'Medium', 'http://buetian14.com/fairmanagementapp/images/stall2_1477939085069'),
(36, 'stall3', 'à¦•à¦ªà¦¾à¦²à¦•à§à¦£à§à¦¡à¦²à¦¾', 'à¦¬à¦™à§à¦•à¦¿à¦®à¦šà¦¨à§à¦¦à§à¦° à¦šà¦Ÿà§à¦Ÿà§‹à¦ªà¦¾à¦§à§à¦¯à¦¾à¦¯à¦¼ ', 'à¦œà¦¨à¦ªà§à¦°à¦¿à§Ÿ à¦¬à¦‡', '120', 'Medium', 'http://buetian14.com/fairmanagementapp/images/stall3_1477939982715'),
(37, 'stall3', 'HaJaBaRaLa', 'Sukumar Ray', 'HaJaBaRaLa or HJBRL: A Nonsense Story is a novella or novelette by Sukumar Ray.', '140', 'High', 'http://buetian14.com/fairmanagementapp/images/stall3_1478239394894'),
(14, 'stall2', 'à¦®à¦¾', 'à¦†à¦¨à¦¿à¦¸à§à¦² à¦¹à¦•', 'à¦œà¦¨à¦ªà§à¦°à¦¿à§Ÿ à¦¬à¦‡', '250', 'High', 'http://buetian14.com/fairmanagementapp/images/stall2_1477939231236'),
(15, 'stall2', 'à¦¦à¦°à¦œà¦¾à¦° à¦“à¦ªà¦¾à¦¶à§‡ ', 'à¦¹à§à¦®à¦¾à§Ÿà§‚à¦¨ à¦†à¦¹à¦®à§‡à¦¦ ', 'à¦¹à¦¿à¦®à§ à¦¸à¦¿à¦°à¦¿à¦œà§‡à¦° à¦¬à¦‡', '350', 'Medium', 'http://buetian14.com/fairmanagementapp/images/stall2_1477939405640'),
(35, 'stall3', 'Parineeta', 'Sarat Chandra Chattopadhyay', 'Parineeta is a 1914 Bengali language novel written by Sarat Chandra Chattopadhyay and is set in Calcutta, India during the early part of the 20th century', '150', 'Out of Stock', 'http://buetian14.com/fairmanagementapp/images/stall3_1477939574050'),
(33, 'stall1', 'Chander Pahar', 'Bibhutibhushan Bandopadhyay ', 'Chander Pahar is a Bengali adventure novel written by Bibhutibhushan Bandopadhyay and published in 1937. The novel followsthe adventures of a young Bengali man in the forests of Africa.', '130', 'Medium', 'http://buetian14.com/fairmanagementapp/images/stall1_1478462344903');

-- --------------------------------------------------------

--
-- Table structure for table `book_fair_16_sells`
--

CREATE TABLE `book_fair_16_sells` (
  `id` int(11) NOT NULL,
  `stall` varchar(20) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `employee_name` varchar(100) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `time` varchar(50) DEFAULT NULL,
  `price` varchar(50) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_fair_16_sells`
--

INSERT INTO `book_fair_16_sells` (`id`, `stall`, `product_name`, `employee_name`, `date`, `time`, `price`, `description`) VALUES
(1, 'stall1', 'Micro Electric Circuit ', 'Ajoy', '6-6-16', '9pm', '250', '2 piece ');

-- --------------------------------------------------------

--
-- Table structure for table `book_fair_16_stalls`
--

CREATE TABLE `book_fair_16_stalls` (
  `id` int(11) NOT NULL,
  `stall` varchar(50) DEFAULT NULL,
  `stall_name` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_fair_16_stalls`
--

INSERT INTO `book_fair_16_stalls` (`id`, `stall`, `stall_name`, `owner`, `description`, `location`) VALUES
(1, 'stall1', 'Annorokom Publication', 'Annorokom Group ', 'Renowned publisher', '23.73023, 90.39719'),
(2, 'stall2', 'Prothoma Publication', 'Transcom Group ', 'Prothoma Publication Book House', '23.73034, 90.3968'),
(3, 'stall3', 'Ankur Publication ', 'Ankur Publication Limited ', 'House of best book', '23.73032, 90.3963'),
(4, 'stall4', 'Somoy Publication ', 'Somoy Publication Limited ', 'Somoy Publication House', '23.73108, 90.39821');

-- --------------------------------------------------------

--
-- Table structure for table `book_fair_16_users`
--

CREATE TABLE `book_fair_16_users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `mobile_no` bigint(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_fair_16_users`
--

INSERT INTO `book_fair_16_users` (`id`, `username`, `password`, `mobile_no`) VALUES
(1, 'stall1', 'stall1', 4323433455),
(2, 'stall2', 'stall2', 432342342),
(3, 'stall3', 'stall3', 4345345),
(4, 'stall4', 'stall4', 7567567567);

-- --------------------------------------------------------

--
-- Table structure for table `fairs`
--

CREATE TABLE `fairs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `db_name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `organizer` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `map_address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fairs`
--

INSERT INTO `fairs` (`id`, `db_name`, `title`, `organizer`, `location`, `start_date`, `end_date`, `open_time`, `close_time`, `map_address`) VALUES
(8, 'book_fair_16', 'Ekushey Boi Mela 2017', 'Bangla Academy ,bd', 'Bangla Academy,Bangladesh', '2017-02-01', '2017-06-30', '09:00:00', '21:00:00', 'https://www.google.com/maps/d/edit?mid=1lGcLL7WSCrilqiBQLTeXetjgIOI'),
(10, 'trade_fair_16', 'Dhaka Internationl Trade Fair 2017', 'Export Promotion Bureau', 'Sher-E-Bangla Nagar,Dhaka,BD', '2016-12-01', '2017-06-30', '09:00:00', '22:00:00', 'https://www.google.com/maps/d/edit?mid=1GnG-tT-9_0L7jWcajHwX4ka-7e4'),
(11, 'trade_fair_17', 'Dhaka Internationl Trade Fair 2018', 'Export Promotion Bureau dhaka', 'Sher-E-Bangla Nagar,Dhaka', '2017-12-01', '2018-01-31', '09:00:00', '22:00:00', 'https://www.google.com/maps/d/edit?mid=1GnG-tT-9_0L7jWcajHwX4ka-7e4'),
(12, 'adex_engenius_17', 'Adex Engenius \'17', 'AUST EEE Society & Department of EEE of Ahsanullah University of Science & Technology', '141 & 142, Love Rd, Dhaka 1208, Bangladesh', '2017-02-03', '2017-02-04', '09:00:00', '19:00:00', 'https://drive.google.com/open?id=1UOL7FGWs2gvxCrshOkVm8fQHpjE&usp=sharing');

-- --------------------------------------------------------

--
-- Table structure for table `trade_fair_16_employees`
--

CREATE TABLE `trade_fair_16_employees` (
  `id` int(11) NOT NULL,
  `stall` varchar(20) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `contact_no` varchar(255) DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `salary` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `trade_fair_16_products`
--

CREATE TABLE `trade_fair_16_products` (
  `id` int(11) NOT NULL,
  `stall` varchar(50) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `price` varchar(25) NOT NULL,
  `availability` varchar(15) DEFAULT NULL,
  `image` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `trade_fair_16_sells`
--

CREATE TABLE `trade_fair_16_sells` (
  `id` int(11) NOT NULL,
  `stall` varchar(20) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `employee_name` varchar(100) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `time` varchar(50) DEFAULT NULL,
  `price` varchar(50) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `trade_fair_16_stalls`
--

CREATE TABLE `trade_fair_16_stalls` (
  `id` int(11) NOT NULL,
  `stall` varchar(50) DEFAULT NULL,
  `stall_name` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trade_fair_16_stalls`
--

INSERT INTO `trade_fair_16_stalls` (`id`, `stall`, `stall_name`, `owner`, `description`, `location`) VALUES
(36, 'stalls1', 'stalls1', 'stalls1', 'stalls1', 'stalls1');

-- --------------------------------------------------------

--
-- Table structure for table `trade_fair_16_users`
--

CREATE TABLE `trade_fair_16_users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `mobile_no` bigint(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trade_fair_16_users`
--

INSERT INTO `trade_fair_16_users` (`id`, `username`, `password`, `mobile_no`) VALUES
(36, 'stalls1', 'qqcedzwe', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `trade_fair_17_employees`
--

CREATE TABLE `trade_fair_17_employees` (
  `id` int(11) NOT NULL,
  `stall` varchar(20) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `contact_no` varchar(255) DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `salary` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trade_fair_17_employees`
--

INSERT INTO `trade_fair_17_employees` (`id`, `stall`, `name`, `description`, `contact_no`, `position`, `salary`) VALUES
(1, 'stall1', 'sazzad', 'magi', '420', '69', '');

-- --------------------------------------------------------

--
-- Table structure for table `trade_fair_17_products`
--

CREATE TABLE `trade_fair_17_products` (
  `id` int(11) NOT NULL,
  `stall` varchar(50) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `price` varchar(25) NOT NULL,
  `availability` varchar(15) DEFAULT NULL,
  `image` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `trade_fair_17_sells`
--

CREATE TABLE `trade_fair_17_sells` (
  `id` int(11) NOT NULL,
  `stall` varchar(20) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `employee_name` varchar(100) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `time` varchar(50) DEFAULT NULL,
  `price` varchar(50) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `trade_fair_17_stalls`
--

CREATE TABLE `trade_fair_17_stalls` (
  `id` int(11) NOT NULL,
  `stall` varchar(50) DEFAULT NULL,
  `stall_name` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trade_fair_17_stalls`
--

INSERT INTO `trade_fair_17_stalls` (`id`, `stall`, `stall_name`, `owner`, `description`, `location`) VALUES
(1, 'stall3', 'stall3', 'stall3', 'stall3', '23.76886, 90.37909'),
(2, 'stall1', 'stall1', 'stall1', 'stall1', '23.76982, 90.37902'),
(3, 'stall2', 'stall2', 'stall2', 'stall2', '23.76936, 90.37908');

-- --------------------------------------------------------

--
-- Table structure for table `trade_fair_17_users`
--

CREATE TABLE `trade_fair_17_users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `mobile_no` bigint(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trade_fair_17_users`
--

INSERT INTO `trade_fair_17_users` (`id`, `username`, `password`, `mobile_no`) VALUES
(1, 'stall3', 'stall3', 2313123),
(2, 'stall1', 'stall1', 32123423),
(3, 'stall2', 'stall2', 43234243);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adex_engenius_17_employees`
--
ALTER TABLE `adex_engenius_17_employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adex_engenius_17_products`
--
ALTER TABLE `adex_engenius_17_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adex_engenius_17_sells`
--
ALTER TABLE `adex_engenius_17_sells`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adex_engenius_17_stalls`
--
ALTER TABLE `adex_engenius_17_stalls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adex_engenius_17_users`
--
ALTER TABLE `adex_engenius_17_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `book_fair_16_employees`
--
ALTER TABLE `book_fair_16_employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book_fair_16_products`
--
ALTER TABLE `book_fair_16_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book_fair_16_sells`
--
ALTER TABLE `book_fair_16_sells`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book_fair_16_stalls`
--
ALTER TABLE `book_fair_16_stalls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book_fair_16_users`
--
ALTER TABLE `book_fair_16_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `fairs`
--
ALTER TABLE `fairs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `trade_fair_16_employees`
--
ALTER TABLE `trade_fair_16_employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trade_fair_16_products`
--
ALTER TABLE `trade_fair_16_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trade_fair_16_sells`
--
ALTER TABLE `trade_fair_16_sells`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trade_fair_16_stalls`
--
ALTER TABLE `trade_fair_16_stalls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trade_fair_16_users`
--
ALTER TABLE `trade_fair_16_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trade_fair_17_employees`
--
ALTER TABLE `trade_fair_17_employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trade_fair_17_products`
--
ALTER TABLE `trade_fair_17_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trade_fair_17_sells`
--
ALTER TABLE `trade_fair_17_sells`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trade_fair_17_stalls`
--
ALTER TABLE `trade_fair_17_stalls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trade_fair_17_users`
--
ALTER TABLE `trade_fair_17_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adex_engenius_17_employees`
--
ALTER TABLE `adex_engenius_17_employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `adex_engenius_17_products`
--
ALTER TABLE `adex_engenius_17_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `adex_engenius_17_sells`
--
ALTER TABLE `adex_engenius_17_sells`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `adex_engenius_17_stalls`
--
ALTER TABLE `adex_engenius_17_stalls`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `adex_engenius_17_users`
--
ALTER TABLE `adex_engenius_17_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `book_fair_16_employees`
--
ALTER TABLE `book_fair_16_employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `book_fair_16_products`
--
ALTER TABLE `book_fair_16_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `book_fair_16_sells`
--
ALTER TABLE `book_fair_16_sells`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `book_fair_16_stalls`
--
ALTER TABLE `book_fair_16_stalls`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `book_fair_16_users`
--
ALTER TABLE `book_fair_16_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `fairs`
--
ALTER TABLE `fairs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `trade_fair_16_employees`
--
ALTER TABLE `trade_fair_16_employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `trade_fair_16_products`
--
ALTER TABLE `trade_fair_16_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `trade_fair_16_sells`
--
ALTER TABLE `trade_fair_16_sells`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `trade_fair_16_stalls`
--
ALTER TABLE `trade_fair_16_stalls`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `trade_fair_16_users`
--
ALTER TABLE `trade_fair_16_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `trade_fair_17_employees`
--
ALTER TABLE `trade_fair_17_employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `trade_fair_17_products`
--
ALTER TABLE `trade_fair_17_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `trade_fair_17_sells`
--
ALTER TABLE `trade_fair_17_sells`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `trade_fair_17_stalls`
--
ALTER TABLE `trade_fair_17_stalls`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `trade_fair_17_users`
--
ALTER TABLE `trade_fair_17_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
